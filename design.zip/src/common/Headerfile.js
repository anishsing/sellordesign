import React, { Component } from 'react'
import {Nav,Navbar} from 'react-bootstrap';
import './common.css';
export default class Headerfile extends Component {
    render() {
        return (
            <div>
               <Navbar bg="light" sticky="bottom" expand="lg">
                    <Navbar.Brand href="#home" className="pt-2 pb-2 logohead" style={{fontSize:'36px'}}>Sellor</Navbar.Brand>
                    <div class="light"></div>
                    <div class="light"></div>
                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav" className="justify-content-end">
                        {/* <Nav className="mr-auto">
                        <Nav.Link href="#home">Home</Nav.Link>
                        <Nav.Link href="#link">Link</Nav.Link>
                        
                        </Nav> */}
                       
                        <Nav className="justify-content-end" activeKey="/home" style={{fontWeight:"bolder",color:'red'}}> 
                            <Nav.Item>
                            <Nav.Link href="/home" className="pr-2">Home</Nav.Link>
                            </Nav.Item>
                            <Nav.Item>
                            <Nav.Link eventKey="link-1" className="pr-2">About</Nav.Link>
                            </Nav.Item>
                            <Nav.Item>
                            <Nav.Link eventKey="link-2" className="pr-2">Services</Nav.Link>
                            </Nav.Item>
                            <Nav.Item>
                            <Nav.Link eventKey="disabled" className="pr-2">
                                Portfolio
                            </Nav.Link>
                            </Nav.Item>
                            <Nav.Item>
                            <Nav.Link href="/home" className="pr-2">Blog</Nav.Link>
                            </Nav.Item>
                            <Nav.Item>
                            <Nav.Link href="/home" className="pr-2">Contact</Nav.Link>
                            </Nav.Item>
                        </Nav>
                    </Navbar.Collapse>
                    </Navbar>
            </div>
        )
    }
}
