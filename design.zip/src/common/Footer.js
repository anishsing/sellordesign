import React, { Component } from 'react'

export default class Footer extends Component {
    render() {
        return (
            <div>
                <p style={{background:'#1b3b4a',color:'#fff',padding:'15px',margin:'0'}}>&copy; All Right Reserve By <span>http://anishsingh.epizy.com/</span> @2021</p>
            </div>
        )
    }
}
