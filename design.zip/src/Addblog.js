import React, { Component } from 'react'
import CKEditor from "react-ckeditor-component";
import {Row,Col, PageHeader,Divider,Input,Card,DatePicker, Skeleton,Space,Select,Rate, Button} from 'antd'
import {ListGroup,InputGroup,FormControl,Form} from 'react-bootstrap'
import moment from 'moment';
import './common/addblog.css'

const { Option } = Select;

export default class Addblog extends Component {


    constructor(props) {
        super(props);
        this.updateContent = this.updateContent.bind(this);
        this.state = {
            content: 'content',
            show:true
        }
    }

    updateContent(newContent) {
        this.setState({
            content: newContent
        })
    }
    
    onChange(evt){
      console.log("onChange fired with event info: ", evt);
      var newContent = evt.editor.getData();
      this.setState({
        content: newContent
      })
    }
    
    onBlur(evt){
      console.log("onBlur event called with event info: ", evt);
    }
    
    afterPaste(evt){
      console.log("afterPaste event called with event info: ", evt);
    }

    componentDidMount=()=>{
        this.setState({ show: true });
            setTimeout(() => {
              this.setState({ show: false });
            }, 2000);
    };
    render() {
        
        const { RangePicker } = DatePicker;

const dateFormat = 'YYYY/MM/DD';

        return (
            <Skeleton loading={this.state.show}>
            <div>
         
                
                <PageHeader
                className="site-page-header"
                onBack={() => null}
                title="Your Hospitality View"
                subTitle=""
            />
               <Divider>Add Blogs</Divider>

             <Row className="divbakground">
           
                 <Col xs={23} sm={23} md={12} lg={14}>
                        <div style={{padding:'14px'}} >
                        <Input placeholder="Enter Title" bordered={false} /><hr />
                        <div className="designsadow">
                        <CKEditor 
                        style={{background:'#fff'}}
                            activeClass="p10" 
                            content={this.state.content} 
                            events={{
                                "blur": this.onBlur,
                                "afterPaste": this.afterPaste,
                                "change": this.onChange
                            }}
                            />
                        </div>
                       
                        </div>
                 </Col>
                 <Col xs={23} sm={23} md={11} lg={9}>

                 <ListGroup as="ul">
                    <ListGroup.Item as="li" active>
                    Post settings
                    </ListGroup.Item>
                    <ListGroup.Item as="li">
                    <Card className="designsadow">
                    <InputGroup size="sm" className="mb-3">
                    <InputGroup.Prepend>
                    <InputGroup.Text id="inputGroup-sizing-sm">Labels</InputGroup.Text>
                    </InputGroup.Prepend>
                    <FormControl aria-label="Small" aria-describedby="inputGroup-sizing-sm" />
                </InputGroup>
                <p>Published on &nbsp;
                <Space direction="vertical" size={12}>
    <DatePicker defaultValue={moment('2015/01/01', dateFormat)} style={{width:'250px'}} format={dateFormat} />
    </Space></p>
                </Card>
                    </ListGroup.Item>
                    <ListGroup.Item as="li" >
                    <Card style={{textAlign:'left'}} className="designsadow">
                    
                    <div >
                    <p>Permalink
      <Input addonBefore="http://" addonAfter=".com" defaultValue="mysite" /></p>
      <p>Rate : &nbsp; <Rate /></p>
      <InputGroup size="sm" className="mb-3">
    <InputGroup.Prepend>
      <InputGroup.Text id="inputGroup-sizing-sm">Location</InputGroup.Text>
    </InputGroup.Prepend>
    <FormControl aria-label="Small" aria-describedby="inputGroup-sizing-sm" />
  </InputGroup>
    </div>
                </Card>
                    </ListGroup.Item>
                    <ListGroup.Item as="li">
                        
                    <Card className="designsadow">
                    <p style={{textAlign:'left'}}>Feature Image</p>
                    <Form.Group>
    <Form.File id="exampleFormControlFile1" />
  </Form.Group>
                </Card>
                    </ListGroup.Item>
                    </ListGroup>
                 
                 </Col>
                 <Button type="primary" >Save Post</Button>
             </Row>
            
            </div>
            </Skeleton>
        )
    }
}
