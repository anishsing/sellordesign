import logo from './logo.svg';
import './App.css';
import Headerfile from './common/Headerfile';
import Footer from './common/Footer';
import Home from './Home';


function App() {
  return (
    <div className="App">
     
      <Headerfile/>


      <Home />

      <Footer/>
    </div>
  );
}

export default App;
