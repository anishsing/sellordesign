import React, { Component } from 'react'
import slide from './img/slide/slide-1.jpg';
import slide1 from './img/slide/slide-2.jpg';
import slide2 from './img/slide/slide-3.jpg';
import client from './img/clients/client-1.png';
import client1 from './img/clients/client-2.png';
import client2 from './img/clients/client-3.png';
import client3 from './img/clients/client-4.png';
import client4 from './img/clients/client-5.png';
import './home.css'
import { DownloadOutlined ,LogoutOutlined} from '@ant-design/icons';
import {Button,Jumbotron,Row,Col,Carousel,Tabs,Tab} from 'react-bootstrap';
import { Skeleton, Switch, Card, Avatar ,Image} from 'antd';
// import {Row,Col} from 'antd'
const { Meta } = Card;
export default class Home extends Component {
    
    render() {
        return (
            <div>
                <Carousel>
                    <Carousel.Item style={{height: '450px'}}>
                        <img
                        className="d-block w-100"
                        src={slide}
                        alt="First slide"
                        width='100%'
                        />
                        <Carousel.Caption>
                        <Jumbotron style={{background: '#e9ecef0d'}}>
                            <h1 className="teaxthead">Hello, world!</h1>
                            <p class="blurOut">
                                This is a simple hero unit, a simple jumbotron-style component for calling
                                extra attention to featured content or information.
                            </p>
                            <p>
                                <Button variant="primary">Learn more</Button>
                            </p>
                            </Jumbotron>
                        </Carousel.Caption>
                    </Carousel.Item>
                    <Carousel.Item style={{height: '450px'}}>
                        <img
                        className="d-block w-100"
                        src={slide1}
                        alt="Second slide"
                        width='100%'
                        />

                        <Carousel.Caption>
                        <Jumbotron style={{background: '#e9ecef0d'}}>
                            <h1 className="teaxthead">Hello, world!</h1>
                            <p class="blurOut">
                                This is a simple hero unit, a simple jumbotron-style component for calling
                                extra attention to featured content or information.
                            </p>
                            <p>
                                <Button variant="primary">Learn more</Button>
                            </p>
                            </Jumbotron> </Carousel.Caption>
                    </Carousel.Item>
                    <Carousel.Item style={{height: '450px',background:'#e3e3e3'}}>
                        <img
                        className="d-block w-100"
                        src={slide2}
                        alt="Third slide"
                        width='100%'
                        />

                        <Carousel.Caption>
                        <Jumbotron style={{background: '#e9ecef0d'}}>
                            <h1 className="teaxthead">Hello, world!</h1>
                            <p class="blurOut">
                                This is a simple hero unit, a simple jumbotron-style component for calling
                                extra attention to featured content or information.
                            </p>
                            <p>
                                <Button variant="primary">Learn more</Button>
                            </p>
                            </Jumbotron>
                        </Carousel.Caption>
                    </Carousel.Item>
                    </Carousel>
                    
                    {/* start down point of end  slider  */}

                  
                    <Row style={{margin:0}}>
    <Col xs={11}lg={6}>
        <div className="About">
        <h2>
            EUM IPSAM LABORUM DELENITI VELITENA
            </h2>
            <h3>
            Voluptatem dignissimos provident quasi corporis voluptates sit assum perenda sruen jonee trave
            </h3>
        </div>
           
    </Col>
    <Col xs={11}lg={6}>
    <div className="Aboutright">
                <p>Ullamco laboris nisi ut aliquip ex ea commodo consequat.
                     Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
                      fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, 
                    sunt in culpa qui officia deserunt mollit anim id est laborum</p>

                 
                     <p><LogoutOutlined /> sunt in culpa qui officia deserunt </p>       
                     <p><LogoutOutlined /> sunt in culpa qui officia deserunt </p> 
                     <p><LogoutOutlined /> sunt in culpa qui officia deserunt </p> 
                     <p><LogoutOutlined /> sunt in culpa qui officia deserunt </p> 
                     <p>Ullamco laboris nisi ut aliquip ex ea commodo consequat.
                     Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
                      fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, 
                    sunt in culpa qui officia deserunt mollit anim id est laborum</p>
                </div>
    
    </Col>

           
  </Row>
                <Row xs={11}style={{margin:'0',background:'#e3e3e3'}} className="p-3">
                    <Col xs={11} md={6} lg={2}>
                    <img
                        className="d-block w-100"
                        src={client}
                        alt="First slide"
                        width='100%'
                        />
                    </Col>
                    <Col xs={11} md={4} lg={2}>
                    <img
                        className="d-block w-100"
                        src={client1}
                        alt="First slide"
                        width='100%'
                        />
                    </Col>
                    <Col xs={11} md={4} lg={2}>
                    <img
                        className="d-block w-100"
                        src={client2}
                        alt="First slide"
                        width='100%'
                        />
                    </Col>
                    <Col xs={11} md={4} lg={2}>
                    <img
                        className="d-block w-100"
                        src={client3}
                        alt="First slide"
                        width='100%'
                        />
                    </Col>
                    <Col xs={11} md={4} lg={2}>
                    <img
                        className="d-block w-100"
                        src={client4}
                        alt="First slide"
                        width='100%'
                        />
                    </Col>
                    
                    </Row>  


                    <Row style={{margin:0,padding:'35px 23px'}} >
                        <Col xs={12}>
                            <Row>
                            <Col xs={11}lg={6}>
                            <Card style={{textAlign:"left",background:'#e4e4e4',padding: '13px'}}>
                                <h4>Lorem Ipsum</h4>
                                <p>Voluptatum deleniti atque corrupti quos 
                                    dolores et quas molestias excepturi sint occaecati cupiditate non provident</p>
                            </Card>
                            </Col>
                            <Col xs={11}lg={6}>
                            <Card style={{textAlign:"left",background:'#e4e4e4',padding: '13px' }}>
                                <h4>Lorem Ipsum</h4>
                                <p>Voluptatum deleniti atque corrupti quos 
                                    dolores et quas molestias excepturi sint occaecati cupiditate non provident</p>
                            </Card>
                            </Col>
                            </Row>
                            
                           
                        </Col>
                        <Col xs={12} className="mt-3">
                            <Row>
                            <Col xs={11}lg={6}>
                            <Card style={{textAlign:"left",background:'#e4e4e4',padding: '13px' }}>
                                <h4>Lorem Ipsum</h4>
                                <p>Voluptatum deleniti atque corrupti quos 
                                    dolores et quas molestias excepturi sint occaecati cupiditate non provident</p>
                            </Card>
                            </Col>
                            <Col xs={11}lg={6}>
                            <Card style={{textAlign:"left",background:'#e4e4e4',padding: '13px' }}>
                                <h4>Lorem Ipsum</h4>
                                <p>Voluptatum deleniti atque corrupti quos 
                                    dolores et quas molestias excepturi sint occaecati cupiditate non provident</p>
                            </Card>
                            </Col>
                            </Row>
                            
                           
                        </Col>
                        <Col xs={12} className="mt-3">
                            <Row>
                            <Col xs={11}lg={6}>
                            <Card style={{textAlign:"left",background:'#e4e4e4',padding: '13px' }}>
                                <h4>Lorem Ipsum</h4>
                                <p>Voluptatum deleniti atque corrupti quos 
                                    dolores et quas molestias excepturi sint occaecati cupiditate non provident</p>
                            </Card>
                            </Col>
                            <Col xs={11} lg={6}>
                            <Card style={{textAlign:"left",background:'#e4e4e4',padding: '13px' }}>
                                <h4>Lorem Ipsum</h4>
                                <p>Voluptatum deleniti atque corrupti quos 
                                    dolores et quas molestias excepturi sint occaecati cupiditate non provident</p>
                            </Card>
                            </Col>
                            </Row>
                            
                           
                        </Col>
                    </Row>  

                 <Row  style={{margin:0,padding:'30px'}}>
                     <Col lg={12}>
                 <Tabs defaultActiveKey="home" id="uncontrolled-tab-example">
                    <Tab eventKey="home" title="Card" className="tab-mainvalue">
                        <div>
                       
                                                </div>
                                                <Row style={{padding:'15px'}}>
    <Col xs={11} lg={4} md={4}>
                        <Image
                            width={200}
                            height={250}
                            className="tabimage"
                            src="https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png"
                            /><br /><p>
                           Voluptatum deleniti atque corrupti
                            quos dolores et quas molestias excepturi sint occaecati cupiditate non provident
                        </p>
    </Col>
    <Col xs={11} lg={4} md={4}>
    <Image
                            width={200}
                            height={250}
                            className="tabimage"
                            src="https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png"
                            /><br /><p>
                           Voluptatum deleniti atque corrupti
                            quos dolores et quas molestias excepturi sint occaecati cupiditate non provident
                        </p>
    </Col>
    <Col xs={11}lg={4} md={4}>
    <Image
                            width={200}
                            height={250}
                            className="tabimage"
                            src="https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png"
                            /><br /><p>
                           Voluptatum deleniti atque corrupti
                            quos dolores et quas molestias excepturi sint occaecati cupiditate non provident
                        </p>
    </Col>
  </Row>
                    </Tab>
                    <Tab eventKey="profile" title="App" className="tab-mainvalue">
                        <p>
                            Profile dayta fgsd dsfsdf 
                        </p>
                    </Tab>
                    <Tab eventKey="contact" title="Web" className="tab-mainvalue" >
                    <Row style={{padding:'15px'}}>
    <Col xs={11}lg={4} md={4}>
                        <Image
                            width={200}
                            height={250}
                            className="tabimage"
                            src="https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png"
                            /><br /><p>
                           Voluptatum deleniti atque corrupti
                            quos dolores et quas molestias excepturi sint occaecati cupiditate non provident
                        </p>
    </Col>
    <Col xs={11}lg={4} md={4}>
    <Image
                            width={200}
                            height={250}
                            className="tabimage"
                            src="https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png"
                            /><br /><p>
                           Voluptatum deleniti atque corrupti
                            quos dolores et quas molestias excepturi sint occaecati cupiditate non provident
                        </p>
    </Col>
    <Col xs={11}lg={4} md={4}>
    <Image
                            width={200}
                            height={250}
                            className="tabimage"
                            src="https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png"
                            /><br /><p>
                           Voluptatum deleniti atque corrupti
                            quos dolores et quas molestias excepturi sint occaecati cupiditate non provident
                        </p>
    </Col>
  </Row>
                    </Tab>
                    </Tabs>
                    </Col>
                 </Row>

                 
            </div>
        )
    }
}
